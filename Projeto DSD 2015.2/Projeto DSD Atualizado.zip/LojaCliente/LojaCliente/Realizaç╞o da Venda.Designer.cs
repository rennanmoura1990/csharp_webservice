﻿namespace LojaCliente
{
    partial class Realização_da_Venda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Realização_da_Venda));
            this.comboBoxFuncionario = new System.Windows.Forms.ComboBox();
            this.txtIDVenda = new System.Windows.Forms.TextBox();
            this.BotaoIniciaVenda = new System.Windows.Forms.Button();
            this.comboBoxCliente = new System.Windows.Forms.ComboBox();
            this.comboBoxFormaPag = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.BotaoAdicionarProduto = new System.Windows.Forms.Button();
            this.BotaoExcluirProduto = new System.Windows.Forms.Button();
            this.txtQtd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxVenda = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.BotaoConsultarVendas = new System.Windows.Forms.Button();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxProdutos = new System.Windows.Forms.ComboBox();
            this.labelvalor = new System.Windows.Forms.Label();
            this.BotaoFinalizaVenda = new System.Windows.Forms.Button();
            this.BotaoAutorizacao = new System.Windows.Forms.Button();
            this.dataSet1 = new System.Data.DataSet();
            this.txtEstoque = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBoxVenda.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxFuncionario
            // 
            this.comboBoxFuncionario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFuncionario.FormattingEnabled = true;
            this.comboBoxFuncionario.Location = new System.Drawing.Point(172, 15);
            this.comboBoxFuncionario.Name = "comboBoxFuncionario";
            this.comboBoxFuncionario.Size = new System.Drawing.Size(198, 21);
            this.comboBoxFuncionario.TabIndex = 0;
            // 
            // txtIDVenda
            // 
            this.txtIDVenda.Enabled = false;
            this.txtIDVenda.Location = new System.Drawing.Point(96, 32);
            this.txtIDVenda.Name = "txtIDVenda";
            this.txtIDVenda.ReadOnly = true;
            this.txtIDVenda.Size = new System.Drawing.Size(100, 20);
            this.txtIDVenda.TabIndex = 1;
            // 
            // BotaoIniciaVenda
            // 
            this.BotaoIniciaVenda.Location = new System.Drawing.Point(202, 30);
            this.BotaoIniciaVenda.Name = "BotaoIniciaVenda";
            this.BotaoIniciaVenda.Size = new System.Drawing.Size(105, 23);
            this.BotaoIniciaVenda.TabIndex = 2;
            this.BotaoIniciaVenda.Text = "Iniciar Venda";
            this.BotaoIniciaVenda.UseVisualStyleBackColor = true;
            this.BotaoIniciaVenda.Click += new System.EventHandler(this.BotaoIniciaVenda_Click);
            // 
            // comboBoxCliente
            // 
            this.comboBoxCliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCliente.FormattingEnabled = true;
            this.comboBoxCliente.Location = new System.Drawing.Point(172, 42);
            this.comboBoxCliente.Name = "comboBoxCliente";
            this.comboBoxCliente.Size = new System.Drawing.Size(198, 21);
            this.comboBoxCliente.TabIndex = 3;
            // 
            // comboBoxFormaPag
            // 
            this.comboBoxFormaPag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFormaPag.FormattingEnabled = true;
            this.comboBoxFormaPag.Location = new System.Drawing.Point(172, 68);
            this.comboBoxFormaPag.Name = "comboBoxFormaPag";
            this.comboBoxFormaPag.Size = new System.Drawing.Size(198, 21);
            this.comboBoxFormaPag.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 162);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.Size = new System.Drawing.Size(768, 276);
            this.dataGridView1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "ID Venda";
            // 
            // BotaoAdicionarProduto
            // 
            this.BotaoAdicionarProduto.Location = new System.Drawing.Point(587, 136);
            this.BotaoAdicionarProduto.Name = "BotaoAdicionarProduto";
            this.BotaoAdicionarProduto.Size = new System.Drawing.Size(75, 23);
            this.BotaoAdicionarProduto.TabIndex = 7;
            this.BotaoAdicionarProduto.Text = "Adicionar";
            this.BotaoAdicionarProduto.UseVisualStyleBackColor = true;
            this.BotaoAdicionarProduto.Click += new System.EventHandler(this.BotaoAdicionarProduto_Click);
            // 
            // BotaoExcluirProduto
            // 
            this.BotaoExcluirProduto.Location = new System.Drawing.Point(668, 136);
            this.BotaoExcluirProduto.Name = "BotaoExcluirProduto";
            this.BotaoExcluirProduto.Size = new System.Drawing.Size(75, 23);
            this.BotaoExcluirProduto.TabIndex = 8;
            this.BotaoExcluirProduto.Text = "Excluir";
            this.BotaoExcluirProduto.UseVisualStyleBackColor = true;
            this.BotaoExcluirProduto.Click += new System.EventHandler(this.BotaoExcluirProduto_Click);
            // 
            // txtQtd
            // 
            this.txtQtd.Location = new System.Drawing.Point(532, 140);
            this.txtQtd.Name = "txtQtd";
            this.txtQtd.Size = new System.Drawing.Size(49, 20);
            this.txtQtd.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(438, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Quantidade";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Funcionário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Forma de Pagamento";
            // 
            // groupBoxVenda
            // 
            this.groupBoxVenda.BackColor = System.Drawing.Color.LightGray;
            this.groupBoxVenda.Controls.Add(this.label4);
            this.groupBoxVenda.Controls.Add(this.txtEstoque);
            this.groupBoxVenda.Controls.Add(this.pictureBox1);
            this.groupBoxVenda.Controls.Add(this.linkLabel1);
            this.groupBoxVenda.Controls.Add(this.BotaoConsultarVendas);
            this.groupBoxVenda.Controls.Add(this.txtPreco);
            this.groupBoxVenda.Controls.Add(this.label10);
            this.groupBoxVenda.Controls.Add(this.label9);
            this.groupBoxVenda.Controls.Add(this.label7);
            this.groupBoxVenda.Controls.Add(this.comboBoxProdutos);
            this.groupBoxVenda.Controls.Add(this.labelvalor);
            this.groupBoxVenda.Controls.Add(this.label3);
            this.groupBoxVenda.Controls.Add(this.label5);
            this.groupBoxVenda.Controls.Add(this.comboBoxFuncionario);
            this.groupBoxVenda.Controls.Add(this.comboBoxCliente);
            this.groupBoxVenda.Controls.Add(this.comboBoxFormaPag);
            this.groupBoxVenda.Controls.Add(this.label2);
            this.groupBoxVenda.Controls.Add(this.dataGridView1);
            this.groupBoxVenda.Controls.Add(this.txtQtd);
            this.groupBoxVenda.Controls.Add(this.BotaoAdicionarProduto);
            this.groupBoxVenda.Controls.Add(this.BotaoExcluirProduto);
            this.groupBoxVenda.Location = new System.Drawing.Point(12, 58);
            this.groupBoxVenda.Name = "groupBoxVenda";
            this.groupBoxVenda.Size = new System.Drawing.Size(780, 444);
            this.groupBoxVenda.TabIndex = 14;
            this.groupBoxVenda.TabStop = false;
            this.groupBoxVenda.Text = "Venda";
            this.groupBoxVenda.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LojaCliente.Properties.Resources.button_27455_960_720;
            this.pictureBox1.Location = new System.Drawing.Point(144, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Enabled = false;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(9, 46);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(56, 16);
            this.linkLabel1.TabIndex = 24;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Cliente";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // BotaoConsultarVendas
            // 
            this.BotaoConsultarVendas.Location = new System.Drawing.Point(12, 109);
            this.BotaoConsultarVendas.Name = "BotaoConsultarVendas";
            this.BotaoConsultarVendas.Size = new System.Drawing.Size(246, 23);
            this.BotaoConsultarVendas.TabIndex = 23;
            this.BotaoConsultarVendas.Text = "Consultar Vendas";
            this.BotaoConsultarVendas.UseVisualStyleBackColor = true;
            this.BotaoConsultarVendas.Click += new System.EventHandler(this.BotaoConsultarVendas_Click);
            // 
            // txtPreco
            // 
            this.txtPreco.Enabled = false;
            this.txtPreco.Location = new System.Drawing.Point(319, 139);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.ReadOnly = true;
            this.txtPreco.Size = new System.Drawing.Size(113, 20);
            this.txtPreco.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(264, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Preço";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(376, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 25);
            this.label9.TabIndex = 20;
            this.label9.Text = "Valor R$";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "Produtos";
            // 
            // comboBoxProdutos
            // 
            this.comboBoxProdutos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProdutos.FormattingEnabled = true;
            this.comboBoxProdutos.Location = new System.Drawing.Point(85, 138);
            this.comboBoxProdutos.Name = "comboBoxProdutos";
            this.comboBoxProdutos.Size = new System.Drawing.Size(173, 21);
            this.comboBoxProdutos.TabIndex = 18;
            this.comboBoxProdutos.SelectedIndexChanged += new System.EventHandler(this.comboBoxProdutos_SelectedIndexChanged);
            // 
            // labelvalor
            // 
            this.labelvalor.AutoSize = true;
            this.labelvalor.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelvalor.Location = new System.Drawing.Point(376, 27);
            this.labelvalor.Name = "labelvalor";
            this.labelvalor.Size = new System.Drawing.Size(158, 73);
            this.labelvalor.TabIndex = 15;
            this.labelvalor.Text = "0.00";
            // 
            // BotaoFinalizaVenda
            // 
            this.BotaoFinalizaVenda.Location = new System.Drawing.Point(432, 32);
            this.BotaoFinalizaVenda.Name = "BotaoFinalizaVenda";
            this.BotaoFinalizaVenda.Size = new System.Drawing.Size(75, 23);
            this.BotaoFinalizaVenda.TabIndex = 15;
            this.BotaoFinalizaVenda.Text = "Finalizar Venda";
            this.BotaoFinalizaVenda.UseVisualStyleBackColor = true;
            this.BotaoFinalizaVenda.Visible = false;
            this.BotaoFinalizaVenda.Click += new System.EventHandler(this.BotaoFinalizaVenda_Click);
            // 
            // BotaoAutorizacao
            // 
            this.BotaoAutorizacao.Location = new System.Drawing.Point(313, 30);
            this.BotaoAutorizacao.Name = "BotaoAutorizacao";
            this.BotaoAutorizacao.Size = new System.Drawing.Size(113, 23);
            this.BotaoAutorizacao.TabIndex = 16;
            this.BotaoAutorizacao.Text = "Pedir Autorização";
            this.BotaoAutorizacao.UseVisualStyleBackColor = true;
            this.BotaoAutorizacao.Visible = false;
            this.BotaoAutorizacao.Click += new System.EventHandler(this.BotaoAutorizacao_Click);
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "NewDataSet";
            // 
            // txtEstoque
            // 
            this.txtEstoque.Enabled = false;
            this.txtEstoque.Location = new System.Drawing.Point(335, 111);
            this.txtEstoque.Name = "txtEstoque";
            this.txtEstoque.Size = new System.Drawing.Size(97, 20);
            this.txtEstoque.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(264, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "Estoque";
            // 
            // Realização_da_Venda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(804, 514);
            this.Controls.Add(this.BotaoAutorizacao);
            this.Controls.Add(this.BotaoFinalizaVenda);
            this.Controls.Add(this.groupBoxVenda);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BotaoIniciaVenda);
            this.Controls.Add(this.txtIDVenda);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Realização_da_Venda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Realização_da_Venda";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBoxVenda.ResumeLayout(false);
            this.groupBoxVenda.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxFuncionario;
        private System.Windows.Forms.TextBox txtIDVenda;
        private System.Windows.Forms.Button BotaoIniciaVenda;
        private System.Windows.Forms.ComboBox comboBoxCliente;
        private System.Windows.Forms.ComboBox comboBoxFormaPag;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BotaoAdicionarProduto;
        private System.Windows.Forms.Button BotaoExcluirProduto;
        private System.Windows.Forms.TextBox txtQtd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBoxVenda;
        private System.Windows.Forms.Label labelvalor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxProdutos;
        private System.Windows.Forms.Button BotaoFinalizaVenda;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button BotaoAutorizacao;
        private System.Windows.Forms.Button BotaoConsultarVendas;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Data.DataSet dataSet1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEstoque;
    }
}